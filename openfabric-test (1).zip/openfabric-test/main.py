import os
import warnings
from ontology_dc8f06af066e4a7880a5938933236037.simple_text import SimpleText

from openfabric_pysdk.context import OpenfabricExecutionRay
from openfabric_pysdk.loader import ConfigClass
from time import time

import numpy as np
import speech_recognition as spr
import transformers

############################################################
# Callback function called on update config
############################################################
def config(configuration: ConfigClass):
    # TODO Add code here
    print("AI is booting...")
    pass


############################################################
# Callback function called on each execution pass
############################################################
def execute(request: SimpleText, ray: OpenfabricExecutionRay) -> SimpleText:
    output = []
    for text in request.text:
        # TODO Add code here
        if any(i in text for i in ["hi","hello"]):
            response = np.random.choice(["Howdy", "Hi", "Hello", "Hi, how can I help you","Hey", "Hi there", "What's up?", "Hi, what's up?"])
        elif any(i in text for i in ["thank you", "thanks"]):
            response = np.random.choice(["You're most welcome", "Do not mention", "It's alright", "Any time", "Of course", "It's my pleasure"], "It's an honour")
        else:
            nlp = transformers.pipeline("conversational", model="microsoft/DialoGPT-medium")
            chat = nlp(transformers.Conversation(text), pad_token_id = 50256)
            response = str(chat)
            response = response[response.find("AI: ") +6:].strip()
        output.append(response)
 
    return SimpleText(dict(text=output))

