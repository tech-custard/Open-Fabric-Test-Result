#!/bin/bash
python ./ignite.py